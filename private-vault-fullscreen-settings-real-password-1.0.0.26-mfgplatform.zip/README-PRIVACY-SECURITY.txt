PRIVATE VAULT — VERSION 1.0.0.26-mfgplatform

What changed (without redesigning the existing app):
- Updated the file picker to allow multiple file types and upload up to 200 files per batch; another batch can be selected after the current batch finishes.
- Added a public Privacy Policy page: privacy-policy.html
- Added a public Account and Data Deletion page: delete-account.html
- Added an in-app Delete Account & All Local Data action. It requires the current account password and the word DELETE.
- Added per-account local deletion of the account record, encrypted files, App Lock data, and remembered session.
- Encrypts file metadata (including names) with the same account-derived key; older local records are migrated on next successful vault load.
- Escaped user-supplied file names before rendering them to reduce HTML/script injection risk.
- Moved the existing app JavaScript into app.js and added Cloudflare Pages security headers in _headers.
- Bumped the service-worker cache version so the new files can be deployed.

IMPORTANT PRODUCT LIMITATIONS
- This release is local-only. Accounts and vault files exist in the browser storage on the device where they were created. There is no cloud account system and no cross-device sync.
- The app does not upload vault files, account passwords, or App Lock PINs to MFG Platform. Cloudflare Pages may process technical request metadata (such as IP address and request details) while serving the website; see Cloudflare's privacy policy.
- The account email and local account records are stored on the device. File contents and file metadata are encrypted locally.
- The app's App Lock PIN is an additional in-app barrier, not hardware-backed authentication and not the file-encryption key.
- If users export/download files, those copies are outside the Vault.
- Local browser data may be lost if website storage is cleared, browser data is reset, or the device is lost/damaged. Users should keep separate backups.

CLOUDFLARE DEPLOYMENT
1. Extract this ZIP.
2. Upload the COMPLETE contents of the extracted folder to the existing Cloudflare Pages project (do not upload the ZIP as a nested folder).
3. Ensure index.html, app.js, manifest.webmanifest, sw.js, _headers, privacy-policy.html, delete-account.html, license.html, LICENSE.txt, and icons/ are at the deployment root.
4. Deploy to the same project and confirm these URLs open publicly:
   - https://private-vault-mfg.pages.dev/
   - https://private-vault-mfg.pages.dev/privacy-policy.html
   - https://private-vault-mfg.pages.dev/delete-account.html

GOOGLE PLAY REVIEW NOTES
- Link privacy-policy.html in the Play Console Privacy Policy field and keep a link inside the app.
- Link delete-account.html in the Play Console account deletion URL field if the app's account-creation flow is submitted. The in-app deletion control is also included.
- Complete the Data safety form only after auditing the final Android package and every included SDK/library. The form must match the actual released package and its providers.
- No ZIP, source code, or policy wording can guarantee Play Store approval. Review the latest Play policies and test the final APK/TWA before submission.
- If cloud login, sync, analytics, ads, crash reporting, or other SDKs are added later, update the policy and Data safety declarations before release.

CONTACT
Privacy support: mfgplatform@gmail.com


SETTINGS UI UPDATE
- Refined only the Settings modal with clearer account, storage, password, App Lock, data management, deletion, and information sections.
- Added a live local vault overview (file count and saved size) and App Lock status.
- Preserved the existing app theme, main-screen layout, file model, login flow, and existing settings actions.
- The storage display is an app-side limit indicator; actual local storage availability depends on the device and browser.


PROFILE PHOTO UPDATE
- Users can choose a JPG, PNG, WEBP, or GIF profile photo (maximum 5 MB) in Settings.
- The image is encrypted using the user's account-derived vault key and saved in that local account record, indexed by the email address.
- The photo is restored when the same local account signs in again on the same browser/device. It is not fetched from the email provider and is not synced to other devices.
- Profile photo data is re-encrypted when the account password is changed and removed when the local account is deleted.


AUTOMATIC UNLOCK + PERFORMANCE UPDATE (14 NOVEMBER 2026)
- When a 4-digit or 6-digit App Lock PIN is entered correctly, the vault unlocks automatically without requiring the Unlock App button. The button and Enter key remain as alternatives.
- The file grid renders up to 60 cards at a time with a Load More control, reads encrypted metadata first. Full file contents are decrypted only when a user opens a photo/video/audio preview or downloads a file.
- Photo/video grid cards show compact preview images instead of only generic icons. New photo/video uploads generate a small thumbnail locally and encrypt it with the account key before saving it in IndexedDB. Older media files are backfilled lazily when their cards approach the screen (up to 128 MB per legacy source file).
- Preview generation is limited to one file at a time on phones; previews are loaded on demand and temporary object URLs are released when cards leave view or the vault locks. Video cards show a play indicator over the first-frame thumbnail.
- Existing files and accounts are kept in the same IndexedDB database; this update does not ask users to clear browser storage or reinstall the app.
- Preview object URLs are revoked when the viewer closes, the vault locks, or the user signs out.
- Added a proprietary-draft software licence at LICENSE.txt and license.html. This is not a government-issued licence or legal opinion; legal review is recommended before commercial release.
- Updated service-worker cache to v10 and added stronger browser security headers.

SECURITY AND PERFORMANCE LIMITATIONS
- The vault remains local-only. Files do not sync to other devices and are not uploaded to a private cloud server.
- AES-GCM encryption protects saved file contents and metadata at rest in browser storage, but the App Lock PIN is an extra in-app barrier, not hardware-backed device security.
- No software can guarantee that files can never be stolen or lost. A compromised/unlocked device, malicious browser extension, malicious software, browser data clearing, or exported copies can expose or remove data.
- The displayed 5 TB limit is an app-side limit indicator, not a promise that a phone/browser has 5 TB of usable storage. Actual limits depend on the device and browser.
- Static syntax and package checks do not replace real-device testing. Test sign-in, automatic 4/6-digit unlock, lock-on-return, file preview/download, deletion, and password change on the target phone before deployment.


VERSION 1.0.0.26-mfgplatform — PHOTO & VIDEO PREVIEW UPDATE
- Fixed thumbnail layering so a loaded photo preview is visible above its fallback icon.
- Added encrypted WebP/PNG thumbnails for newly uploaded photos and videos.
- Added lazy encrypted thumbnail generation for older media records up to 64 MB; generated thumbnails are saved encrypted in the existing file record.
- Video cards display a first-frame thumbnail with a play indicator; tapping the card still opens the secure in-app viewer.
- Re-encrypts saved thumbnails when the account password changes.
- Service-worker cache bumped to v10.
- Version label displayed in the About panel and stored in the app metadata.

TESTING NOTE
- Static syntax, HTML, manifest and ZIP checks are included in this build process. Real Android/Chrome testing is still required, especially for video codecs, large media files, password changes, and existing records.
- Existing legacy media files larger than 128 MB without a saved thumbnail may still show a fallback icon; newly added media stores compact encrypted thumbnails when the device browser can decode the format.
