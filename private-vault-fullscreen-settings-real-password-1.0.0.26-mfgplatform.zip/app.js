const APP_VERSION = '1.0.0.26-mfgplatform';
    const MAX_LEGACY_GRID_PREVIEW_BYTES = 128 * 1024 * 1024;
    const DB_NAME = 'PrivateVaultDB_v2';
    const DB_VERSION = 2;
    const STORE_FILES = 'files';
    const STORE_ACCOUNTS = 'accounts';
    const STORE_SESSION = 'session';
    let db = null;
    let currentEmail = null;
    let currentKey = null;
    let currentAccount = null;
    let profilePhotoObjectUrl = null;
    let viewerObjectUrl = null;
    let gridThumbObserver = null;
    const gridThumbUrls = new Map();
    const gridThumbQueue = [];
    let activeGridThumbLoads = 0;
    let unlockAttemptInProgress = false;
    let appLockNeedsRefresh = false;
    let accountPasswordNeedsUpgrade = false;
    let lockOnReturn = false;
    let lockFailedAttempts = 0;
    let lockBlockedUntil = 0;
    let loginFailedAttempts = 0;
    let loginBlockedUntil = 0;
    let files = [];
    let currentFilter = 'all';
    let gridDisplayLimit = 60;
    let selectedId = null;
    const GRID_PAGE_SIZE = 60;
    const MAX_BATCH = 200; // Max files selectable / uploadable at one time
    const MAX_STORAGE = 5 * 1024 * 1024 * 1024 * 1024; // 5 TB total storage limit

    async function deriveKey(password, salt, iterations = 150000) {
      const enc = new TextEncoder();
      const keyMaterial = await crypto.subtle.importKey(
        'raw', enc.encode(password), 'PBKDF2', false, ['deriveKey']
      );
      return crypto.subtle.deriveKey(
        { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
        keyMaterial,
        { name: 'AES-GCM', length: 256 },
        false,
        ['encrypt', 'decrypt']
      );
    }

    async function encryptData(key, data) {
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, data);
      const result = new Uint8Array(iv.length + encrypted.byteLength);
      result.set(iv, 0);
      result.set(new Uint8Array(encrypted), iv.length);
      return result;
    }

    async function decryptData(key, data) {
      const iv = data.slice(0, 12);
      const ciphertext = data.slice(12);
      return crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext);
    }

    function bufToB64(buf) {
      let binary = '';
      const bytes = new Uint8Array(buf);
      for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
      return btoa(binary);
    }

    function b64ToBuf(b64) {
      const binary = atob(b64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      return bytes.buffer;
    }

    function openDB() {
      return new Promise((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = (e) => {
          const database = e.target.result;
          if (!database.objectStoreNames.contains(STORE_FILES)) {
            const store = database.createObjectStore(STORE_FILES, { keyPath: 'id' });
            store.createIndex('email', 'email', { unique: false });
          }
          if (!database.objectStoreNames.contains(STORE_ACCOUNTS)) {
            database.createObjectStore(STORE_ACCOUNTS, { keyPath: 'email' });
          }
          if (!database.objectStoreNames.contains(STORE_SESSION)) {
            database.createObjectStore(STORE_SESSION, { keyPath: 'id' });
          }
        };
        req.onsuccess = () => {
          req.result.onversionchange = () => req.result.close();
          resolve(req.result);
        };
        req.onerror = () => reject(req.error);
      });
    }

    async function getAccount(email) {
      return new Promise((resolve) => {
        const tx = db.transaction(STORE_ACCOUNTS, 'readonly');
        const req = tx.objectStore(STORE_ACCOUNTS).get(email.toLowerCase());
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => resolve(null);
      });
    }

    async function saveAccount(account) {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_ACCOUNTS, 'readwrite');
        tx.objectStore(STORE_ACCOUNTS).put(account);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    }

    // Keep the derived, non-extractable CryptoKey in IndexedDB; never store the raw password.
    async function savePersistentSession(email, key) {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_SESSION, 'readwrite');
        tx.objectStore(STORE_SESSION).put({ id: 'active', email: email.toLowerCase(), key, savedAt: Date.now() });
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error || new Error('Could not save persistent session'));
        tx.onabort = () => reject(tx.error || new Error('Persistent session save was aborted'));
      });
    }

    async function getPersistentSession() {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_SESSION, 'readonly');
        const req = tx.objectStore(STORE_SESSION).get('active');
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => reject(req.error || new Error('Could not read persistent session'));
      });
    }

    async function clearPersistentSession() {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_SESSION, 'readwrite');
        tx.objectStore(STORE_SESSION).delete('active');
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error || new Error('Could not clear persistent session'));
        tx.onabort = () => reject(tx.error || new Error('Persistent session clear was aborted'));
      });
    }

    async function saveFileRecord(record) {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_FILES, 'readwrite');
        tx.objectStore(STORE_FILES).put(record);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    }

    async function savePasswordMigration(records, account) {
      return new Promise((resolve, reject) => {
        const tx = db.transaction([STORE_FILES, STORE_ACCOUNTS], 'readwrite');
        const fileStore = tx.objectStore(STORE_FILES);
        for (const record of records) fileStore.put(record);
        tx.objectStore(STORE_ACCOUNTS).put(account);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error || new Error('Password update transaction aborted'));
      });
    }

    async function loadFilesForEmail(email) {
      return new Promise((resolve) => {
        const tx = db.transaction(STORE_FILES, 'readonly');
        const index = tx.objectStore(STORE_FILES).index('email');
        const req = index.getAll(email.toLowerCase());
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => resolve([]);
      });
    }

    // Fast startup path: read only the small metadata fields from each cursor row.
    // The encrypted file payload is fetched and decrypted only when a user previews or downloads it.
    function loadFileMetadataForEmail(email) {
      return new Promise((resolve, reject) => {
        const rows = [];
        const tx = db.transaction(STORE_FILES, 'readonly');
        const index = tx.objectStore(STORE_FILES).index('email');
        const req = index.openCursor(IDBKeyRange.only(email.toLowerCase()));
        req.onsuccess = () => {
          const cursor = req.result;
          if (!cursor) return;
          const record = cursor.value;
          rows.push({
            id: record.id,
            meta: record.meta || null,
            name: record.name,
            mime: record.mime,
            size: record.size,
            type: record.type,
            added: record.added,
            hasThumb: Boolean(record.thumb)
          });
          cursor.continue();
        };
        req.onerror = () => reject(req.error || new Error('Could not read vault metadata'));
        tx.oncomplete = () => resolve(rows);
        tx.onerror = () => reject(tx.error || new Error('Could not read vault metadata'));
        tx.onabort = () => reject(tx.error || new Error('Vault metadata read was aborted'));
      });
    }

    function getFileRecord(id) {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_FILES, 'readonly');
        const req = tx.objectStore(STORE_FILES).get(id);
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => reject(req.error || new Error('Could not open this file'));
      });
    }

    function saveEncryptedFileThumbnail(id, encryptedThumbnail, mime) {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_FILES, 'readwrite');
        const store = tx.objectStore(STORE_FILES);
        const req = store.get(id);
        req.onsuccess = () => {
          const record = req.result;
          if (!record) return;
          record.thumb = bufToB64(encryptedThumbnail);
          record.thumbMime = mime || 'image/webp';
          store.put(record);
        };
        req.onerror = () => tx.abort();
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error || new Error('Could not save thumbnail'));
        tx.onabort = () => reject(tx.error || new Error('Thumbnail save was aborted'));
      });
    }

    function canvasToBlob(canvas, mime = 'image/webp', quality = 0.78) {
      return new Promise(resolve => {
        try { canvas.toBlob(resolve, mime, quality); }
        catch (_) { resolve(null); }
      });
    }

    async function createImageThumbnail(sourceBlob) {
      if (typeof createImageBitmap !== 'function') return null;
      let bitmap;
      try {
        bitmap = await createImageBitmap(sourceBlob);
        const scale = Math.min(1, 480 / Math.max(bitmap.width, bitmap.height));
        const width = Math.max(1, Math.round(bitmap.width * scale));
        const height = Math.max(1, Math.round(bitmap.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const context = canvas.getContext('2d', { alpha: true });
        if (!context) return null;
        context.drawImage(bitmap, 0, 0, width, height);
        return await canvasToBlob(canvas, 'image/webp', 0.78)
          || await canvasToBlob(canvas, 'image/png');
      } catch (error) {
        console.warn('Image thumbnail generation failed:', error);
        return null;
      } finally {
        if (bitmap && typeof bitmap.close === 'function') bitmap.close();
      }
    }

    async function createVideoThumbnail(sourceBlob) {
      return new Promise(resolve => {
        const sourceUrl = URL.createObjectURL(sourceBlob);
        const video = document.createElement('video');
        let finished = false;
        let seekRequested = false;
        let timeoutId = null;

        const cleanup = () => {
          if (timeoutId !== null) clearTimeout(timeoutId);
          video.pause();
          video.removeAttribute('src');
          try { video.load(); } catch (_) {}
          URL.revokeObjectURL(sourceUrl);
        };
        const finish = async () => {
          if (finished) return;
          finished = true;
          let result = null;
          try {
            if (video.videoWidth > 0 && video.videoHeight > 0) {
              const scale = Math.min(1, 480 / Math.max(video.videoWidth, video.videoHeight));
              const canvas = document.createElement('canvas');
              canvas.width = Math.max(1, Math.round(video.videoWidth * scale));
              canvas.height = Math.max(1, Math.round(video.videoHeight * scale));
              const context = canvas.getContext('2d');
              if (context) {
                context.drawImage(video, 0, 0, canvas.width, canvas.height);
                result = await canvasToBlob(canvas, 'image/webp', 0.78)
                  || await canvasToBlob(canvas, 'image/png');
              }
            }
          } catch (error) {
            console.warn('Video thumbnail generation failed:', error);
          }
          cleanup();
          resolve(result);
        };

        video.muted = true;
        video.playsInline = true;
        video.preload = 'metadata';
        video.addEventListener('loadedmetadata', () => {
          const duration = Number(video.duration);
          const target = Number.isFinite(duration) && duration > 0.3
            ? Math.min(0.2, duration / 4) : 0;
          if (target > 0.01) {
            seekRequested = true;
            try { video.currentTime = target; }
            catch (_) { finish(); }
          }
        }, { once: true });
        video.addEventListener('seeked', finish, { once: true });
        video.addEventListener('loadeddata', () => {
          if (!seekRequested) finish();
        }, { once: true });
        video.addEventListener('error', finish, { once: true });
        timeoutId = setTimeout(finish, 9000);
        video.src = sourceUrl;
        video.load();
      });
    }

    async function createMediaThumbnail(sourceBlob, type) {
      if (type === 'image') return createImageThumbnail(sourceBlob);
      if (type === 'video') return createVideoThumbnail(sourceBlob);
      return null;
    }

    function updateEncryptedFileMetadata(id, encryptedMetadata) {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_FILES, 'readwrite');
        const store = tx.objectStore(STORE_FILES);
        const req = store.get(id);
        req.onsuccess = () => {
          const record = req.result;
          if (!record) return;
          record.meta = bufToB64(encryptedMetadata);
          delete record.name;
          delete record.mime;
          delete record.size;
          delete record.type;
          delete record.added;
          store.put(record);
        };
        req.onerror = () => tx.abort();
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error || new Error('Could not protect file metadata'));
        tx.onabort = () => reject(tx.error || new Error('File metadata update was aborted'));
      });
    }

    // Destructive actions require the real account password, never the App Lock PIN.
    async function verifyRealPasswordForDestructiveAction(actionLabel) {
      if (!currentAccount || !currentEmail) {
        toast('Please sign in again before deleting data');
        return false;
      }
      let entered = window.prompt('Confirm your ACCOUNT PASSWORD to ' + actionLabel + '. App Lock PIN is not accepted.');
      if (entered === null) return false;
      if (!entered) {
        toast('Account password is required');
        return false;
      }
      const valid = await passwordMatchesAccount(entered, currentAccount);
      entered = '';
      if (!valid) {
        toast('Incorrect account password. Nothing was deleted.');
        return false;
      }
      return true;
    }

    async function deleteFileRecord(id) {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_FILES, 'readwrite');
        tx.objectStore(STORE_FILES).delete(id);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    }

    async function deleteAllFilesForEmail(email) {
      const all = await loadFilesForEmail(email);
      for (const f of all) {
        await deleteFileRecord(f.id);
      }
    }

    async function deleteLocalAccountAndData(email) {
      const normalizedEmail = email.toLowerCase();
      return new Promise((resolve, reject) => {
        const tx = db.transaction([STORE_FILES, STORE_ACCOUNTS, STORE_SESSION], 'readwrite');
        const fileStore = tx.objectStore(STORE_FILES);
        const index = fileStore.index('email');
        const cursorRequest = index.openCursor(IDBKeyRange.only(normalizedEmail));
        cursorRequest.onsuccess = () => {
          const cursor = cursorRequest.result;
          if (cursor) {
            cursor.delete();
            cursor.continue();
          }
        };
        cursorRequest.onerror = () => tx.abort();
        tx.objectStore(STORE_ACCOUNTS).delete(normalizedEmail);
        const sessionStore = tx.objectStore(STORE_SESSION);
        const sessionRequest = sessionStore.get('active');
        sessionRequest.onsuccess = () => {
          if (sessionRequest.result && sessionRequest.result.email === normalizedEmail) {
            sessionStore.delete('active');
          }
        };
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error || new Error('Account deletion failed'));
        tx.onabort = () => reject(tx.error || new Error('Account deletion was cancelled'));
      });
    }

    function showScreen(id) {
      document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
      document.getElementById(id).classList.add('active');
    }

    function setupPasswordVisibility() {
      document.querySelectorAll('input[type="password"]').forEach(input => {
        if (input.dataset.passwordToggleReady === 'true') return;
        input.dataset.passwordToggleReady = 'true';

        const wrapper = document.createElement('div');
        wrapper.className = 'password-field';
        wrapper.style.maxWidth = input.style.maxWidth || '300px';
        wrapper.style.marginBottom = input.style.marginBottom || '12px';
        input.style.maxWidth = 'none';
        input.style.marginBottom = '0';
        input.style.paddingRight = '54px';
        input.parentNode.insertBefore(wrapper, input);
        wrapper.appendChild(input);

        const toggle = document.createElement('button');
        toggle.type = 'button';
        toggle.className = 'password-toggle';
        toggle.textContent = '👁';
        toggle.setAttribute('aria-label', 'Show password');
        toggle.setAttribute('aria-pressed', 'false');
        toggle.addEventListener('click', () => {
          const show = input.type === 'password';
          input.type = show ? 'text' : 'password';
          toggle.textContent = show ? '🙈' : '👁';
          toggle.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
          toggle.setAttribute('aria-pressed', show ? 'true' : 'false');
        });
        wrapper.appendChild(toggle);
      });
    }

    function toast(msg) {
      const t = document.getElementById('toast');
      t.textContent = msg;
      t.classList.add('show');
      setTimeout(() => t.classList.remove('show'), 2500);
    }

    function getFileType(mime, name) {
      const lower = (name || '').toLowerCase();
      if (mime.startsWith('image/')) return 'image';
      if (mime.startsWith('video/')) return 'video';
      if (mime.startsWith('audio/')) return 'audio';
      if (lower.endsWith('.apk') || mime === 'application/vnd.android.package-archive') return 'apk';
      return 'file';
    }

    function escapeHTML(value) {
      return String(value ?? '').replace(/[&<>"']/g, ch => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
      })[ch]);
    }

    function formatSize(bytes) {
      if (bytes < 1024) return bytes + ' B';
      if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
      return (bytes / 1048576).toFixed(1) + ' MB';
    }

    // Password rules: at least 9 characters, letters + numbers + a symbol,
    // and no common sequences, phone-number-like digit strings, or account-name tokens.
    function validateStrongPassword(password, email) {
      if (password.length < 9) return 'Use at least 9 characters.';
      if (password.length > 128) return 'Password must be 128 characters or fewer.';
      if (/\s/.test(password)) return 'Spaces are not allowed in passwords.';
      if (!/[A-Za-z]/.test(password) || !/\d/.test(password) || !/[^A-Za-z0-9]/.test(password)) {
        return 'Use letters, numbers, and at least one symbol (for example @, #, or .).';
      }

      const lower = password.toLowerCase();
      const compact = lower.replace(/[^a-z0-9]/g, '');
      const digitsOnly = password.replace(/\D/g, '');
      const blocked = [
        '123456', '147258', '2583690', '4567890', '1234560',
        '654321', '987654', '000000', '111111', '121212',
        'password', 'passw0rd', 'qwerty', 'asdfgh', 'zxcvbn',
        'letmein', 'welcome', 'admin123', 'abc123'
      ];
      if (blocked.some(pattern => compact.includes(pattern))) {
        return 'This password contains an easy or commonly guessed pattern. Choose another one.';
      }
      if (digitsOnly.length >= 8) {
        return 'Do not use a mobile number or 8 or more digits from a phone number.';
      }
      if (/^1234abcd/.test(compact)) {
        return 'Do not use the predictable pattern 1234abcd.';
      }
      if (/^(.)\1{5,}$/.test(compact)) {
        return 'Do not repeat the same character many times.';
      }

      // The app has no separate profile-name field, so the email username is used
      // as the available account-name check.
      const localPart = (email || '').split('@')[0].toLowerCase();
      const nameTokens = localPart.split(/[^a-z0-9]+/).filter(token => token.length >= 4);
      const joinedName = localPart.replace(/[^a-z0-9]/g, '');
      if (joinedName.length >= 5) nameTokens.push(joinedName);
      if (nameTokens.some(token => compact.includes(token))) {
        return 'Do not use your email username or name in your password.';
      }
      return '';
    }

    async function passwordMatchesAccount(password, account) {
      try {
        const salt = new Uint8Array(b64ToBuf(account.salt));
        const key = await deriveKey(password, salt);
        const plain = await decryptData(key, new Uint8Array(b64ToBuf(account.verify)));
        return new TextDecoder().decode(plain) === 'VAULT_OK';
      } catch (_) {
        return false;
      }
    }

    function validateAppLockPin(pin, requiredLength) {
      if (!/^\d+$/.test(pin)) return 'App Lock PIN must contain numbers only.';
      if (pin.length !== requiredLength) return 'Enter exactly ' + requiredLength + ' digits.';
      if (/^(\d)\1+$/.test(pin)) return 'Do not use a PIN with the same digit repeated.';
      const weakPins = new Set([
        '0000', '1111', '1212', '1234', '1357', '1470', '2468', '2580', '4321', '5555', '6969', '7777', '8080', '8888', '9876',
        '000000', '111111', '112233', '121212', '123123', '123456', '135790', '147258', '159357', '222222', '246810', '258369',
        '333333', '444444', '555555', '654321', '666666', '777777', '888888', '987654', '999999'
      ]);
      if (weakPins.has(pin)) return 'This PIN is too easy to guess. Choose a different number.';
      const ascending = '0123456789';
      const descending = '9876543210';
      if (ascending.includes(pin) || descending.includes(pin)) return 'Do not use a sequential PIN.';
      return '';
    }

    function syncAppLockPinLength() {
      const select = document.getElementById('appLockPinLength');
      const length = Number(select?.value || 6);
      for (const id of ['appLockPassword', 'appLockPassword2']) {
        const input = document.getElementById(id);
        if (!input) continue;
        input.maxLength = length;
        input.inputMode = 'numeric';
        input.pattern = '[0-9]*';
        input.placeholder = (id === 'appLockPassword' ? 'New ' : 'Confirm ') + length + '-digit App Lock PIN';
        if (input.value.length > length) input.value = input.value.slice(0, length);
      }
    }

    function syncUnlockPinLength() {
      const input = document.getElementById('appUnlockPassword');
      if (!input) return;
      const length = Number(currentAccount?.lockLength || 0);
      if (length === 4 || length === 6) {
        input.maxLength = length;
        input.inputMode = 'numeric';
        input.pattern = '[0-9]*';
        input.placeholder = 'Enter ' + length + '-digit App Lock PIN';
      } else {
        input.maxLength = 128;
        input.removeAttribute('inputmode');
        input.removeAttribute('pattern');
        input.placeholder = 'App Lock Password';
      }
    }

    async function verifyAppLockPassword(password, account) {
      if (!account || !account.lockSalt || !account.lockVerify) return false;
      try {
        const salt = new Uint8Array(b64ToBuf(account.lockSalt));
        const key = await deriveKey(password, salt, account.lockIterations || 250000);
        const plain = await decryptData(key, new Uint8Array(b64ToBuf(account.lockVerify)));
        return new TextDecoder().decode(plain) === 'APP_LOCK_OK';
      } catch (_) {
        return false;
      }
    }

    function updateLockButton() {
      const button = document.getElementById('lockBtn');
      if (button) button.style.display = currentAccount && currentAccount.lockVerify ? 'flex' : 'none';
    }

    function releaseViewerObjectUrl() {
      if (viewerObjectUrl) {
        URL.revokeObjectURL(viewerObjectUrl);
        viewerObjectUrl = null;
      }
    }

    function clearGridThumbnailUrls() {
      if (gridThumbObserver) {
        gridThumbObserver.disconnect();
        gridThumbObserver = null;
      }
      for (const url of gridThumbUrls.values()) URL.revokeObjectURL(url);
      gridThumbUrls.clear();
      gridThumbQueue.length = 0;
    }

    async function getDecryptedFileBlob(fileInfo) {
      const key = currentKey;
      const email = currentEmail;
      if (!key || !email || !fileInfo) throw new Error('Vault is locked');
      const record = await getFileRecord(fileInfo.id);
      if (!record || record.email !== email.toLowerCase()) throw new Error('File is not available in this account');
      const plain = await decryptData(key, new Uint8Array(b64ToBuf(record.data)));
      if (currentKey !== key || currentEmail !== email) throw new Error('Vault session changed');
      return new Blob([plain], { type: fileInfo.mime || 'application/octet-stream' });
    }

    async function loadGridThumbnail(element) {
      const fileInfo = files.find(file => file.id === element.dataset.lazyThumb);
      const key = currentKey;
      const email = currentEmail;
      if (!fileInfo || !key || !email) return;

      const record = await getFileRecord(fileInfo.id);
      if (!record || record.email !== email.toLowerCase()) return;
      let thumbnailBlob = null;

      if (record.thumb) {
        const thumbnailBytes = await decryptData(key, new Uint8Array(b64ToBuf(record.thumb)));
        thumbnailBlob = new Blob([thumbnailBytes], { type: record.thumbMime || 'image/webp' });
      } else {
        // Older files have no saved thumbnail. Generate one lazily only for
        // reasonably sized legacy files, then store the thumbnail encrypted.
        if (fileInfo.size > MAX_LEGACY_GRID_PREVIEW_BYTES) return;
        const sourceBlob = await getDecryptedFileBlob(fileInfo);
        thumbnailBlob = await createMediaThumbnail(sourceBlob, fileInfo.type);
        if (!thumbnailBlob && fileInfo.type === 'image') thumbnailBlob = sourceBlob;
        if (thumbnailBlob && thumbnailBlob !== sourceBlob && currentKey === key && currentEmail === email) {
          try {
            const encryptedThumbnail = await encryptData(key, await thumbnailBlob.arrayBuffer());
            await saveEncryptedFileThumbnail(fileInfo.id, encryptedThumbnail, thumbnailBlob.type || 'image/webp');
            fileInfo.hasThumb = true;
          } catch (saveError) {
            console.warn('Could not save generated encrypted thumbnail:', saveError);
          }
        }
      }

      if (!thumbnailBlob || !element.isConnected || element.dataset.visible !== 'true'
          || currentKey !== key || currentEmail !== email) return;
      const url = URL.createObjectURL(thumbnailBlob);
      gridThumbUrls.set(element, url);
      element.src = url;
    }

    function processGridThumbnailQueue() {
      while (activeGridThumbLoads < 1 && gridThumbQueue.length) {
        const element = gridThumbQueue.shift();
        if (!element || !element.isConnected || element.dataset.visible !== 'true') {
          if (element) element.dataset.thumbnailLoading = 'false';
          continue;
        }
        activeGridThumbLoads++;
        loadGridThumbnail(element).catch(error => {
          console.warn('Preview thumbnail unavailable:', error);
        }).finally(() => {
          activeGridThumbLoads--;
          element.dataset.thumbnailLoading = 'false';
          processGridThumbnailQueue();
        });
      }
    }

    function enqueueGridThumbnail(element) {
      if (!element || element.dataset.thumbnailLoading === 'true' || gridThumbUrls.has(element)) return;
      element.dataset.thumbnailLoading = 'true';
      gridThumbQueue.push(element);
      processGridThumbnailQueue();
    }

    function observeGridThumbnails(grid) {
      const elements = grid.querySelectorAll('[data-lazy-thumb]');
      if (!elements.length) return;
      if (!('IntersectionObserver' in window)) {
        elements.forEach((element, index) => {
          if (index < 10) {
            element.dataset.visible = 'true';
            enqueueGridThumbnail(element);
          }
        });
        return;
      }
      gridThumbObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          const element = entry.target;
          if (entry.isIntersecting) {
            element.dataset.visible = 'true';
            enqueueGridThumbnail(element);
          } else {
            element.dataset.visible = 'false';
            const url = gridThumbUrls.get(element);
            if (url) {
              URL.revokeObjectURL(url);
              gridThumbUrls.delete(element);
              element.removeAttribute('src');
            }
          }
        });
      }, { rootMargin: '180px' });
      elements.forEach(element => gridThumbObserver.observe(element));
    }

    function clearVaultViewForLock() {
      files = [];
      clearGridThumbnailUrls();
      releaseViewerObjectUrl();
      const grid = document.getElementById('fileGrid');
      if (grid) grid.innerHTML = '';
      const empty = document.getElementById('emptyState');
      if (empty) empty.hidden = true;
      const loadMore = document.getElementById('loadMoreFilesBtn');
      if (loadMore) loadMore.hidden = true;
      const viewerContent = document.getElementById('viewerContent');
      if (viewerContent) viewerContent.innerHTML = '';
      document.getElementById('viewerModal').classList.remove('active');
      document.getElementById('settingsModal').classList.remove('active');
      document.getElementById('aboutModal').classList.remove('active');
      document.getElementById('privacyModal').classList.remove('active');
      clearProfilePhotoObjectUrl();
      const profileImage = document.getElementById('settingsProfilePhoto');
      const profileFallback = document.getElementById('settingsProfileFallback');
      if (profileImage) { profileImage.removeAttribute('src'); profileImage.hidden = true; }
      if (profileFallback) profileFallback.hidden = false;
      selectedId = null;
    }

    function lockApp() {
      if (!currentEmail || !currentKey || !currentAccount || !currentAccount.lockVerify) {
        toast('Set an App Lock Password in Settings first');
        return;
      }
      if (document.getElementById('appLockModal').classList.contains('active')) return;
      clearVaultViewForLock();
      appLockNeedsRefresh = true;
      document.getElementById('appUnlockPassword').value = '';
      syncUnlockPinLength();
      document.getElementById('appLockError').textContent = '';
      document.getElementById('appLockModal').classList.add('active');
      setTimeout(() => document.getElementById('appUnlockPassword').focus(), 0);
    }

    async function unlockApp() {
      if (unlockAttemptInProgress) return;
      unlockAttemptInProgress = true;
      const error = document.getElementById('appLockError');
      const input = document.getElementById('appUnlockPassword');
      const button = document.getElementById('unlockAppBtn');
      error.textContent = '';
      input.disabled = true;
      button.disabled = true;
      button.textContent = 'Checking...';
      try {
        if (Date.now() < lockBlockedUntil) {
          const seconds = Math.ceil((lockBlockedUntil - Date.now()) / 1000);
          input.value = '';
          error.textContent = 'Too many attempts. Try again in ' + seconds + ' seconds.';
          return;
        }
        const password = input.value;
        if (!password) {
          error.textContent = currentAccount?.lockLength ? 'Enter your App Lock PIN.' : 'Enter your App Lock Password.';
          return;
        }
        if ((currentAccount?.lockLength === 4 || currentAccount?.lockLength === 6) && !/^\d+$/.test(password)) {
          input.value = '';
          error.textContent = 'App Lock PIN must contain numbers only.';
          return;
        }
        const valid = await verifyAppLockPassword(password, currentAccount);
        input.value = '';
        if (!valid) {
          lockFailedAttempts++;
          if (lockFailedAttempts >= 5) {
            lockFailedAttempts = 0;
            lockBlockedUntil = Date.now() + 30000;
            error.textContent = 'Too many incorrect attempts. App Lock is paused for 30 seconds.';
          } else {
            error.textContent = 'Incorrect App Lock Password. Attempts left before a short pause: ' + (5 - lockFailedAttempts) + '.';
          }
          return;
        }
        lockFailedAttempts = 0;
        lockBlockedUntil = 0;
        document.getElementById('appLockModal').classList.remove('active');
        if (appLockNeedsRefresh) {
          appLockNeedsRefresh = false;
          await refreshFiles();
        }
        await updateProfilePhotoUI();
        if (accountPasswordNeedsUpgrade) {
          accountPasswordNeedsUpgrade = false;
          toast('Please update your old account password in Settings');
        } else {
          toast('Vault unlocked');
        }
      } catch (unlockError) {
        console.error('App unlock failed:', unlockError);
        error.textContent = 'Could not open the vault. Please try again.';
      } finally {
        unlockAttemptInProgress = false;
        input.disabled = false;
        button.disabled = false;
        button.textContent = 'Unlock App';
      }
    }

    async function setAppLockPassword() {
      const error = document.getElementById('appLockSettingsError');
      const currentPass = document.getElementById('appLockCurrentPassword').value;
      const pass = document.getElementById('appLockPassword').value;
      const pass2 = document.getElementById('appLockPassword2').value;
      const pinLength = Number(document.getElementById('appLockPinLength').value || 6);
      error.style.color = 'var(--danger)';
      error.textContent = '';

      if (pinLength !== 4 && pinLength !== 6) {
        error.textContent = 'Choose either a 4-digit or 6-digit PIN.';
        return;
      }
      const policyError = validateAppLockPin(pass, pinLength);
      if (policyError) { error.textContent = policyError; return; }
      if (pass !== pass2) { error.textContent = 'App Lock PINs do not match.'; return; }
      if (pass === currentPass && currentPass) {
        error.textContent = 'Choose a new PIN different from your current App Lock credential.';
        return;
      }
      if (await passwordMatchesAccount(pass, currentAccount)) {
        error.textContent = 'App Lock PIN must be different from your account password.';
        return;
      }
      if (currentAccount.lockVerify && !(await verifyAppLockPassword(currentPass, currentAccount))) {
        error.textContent = 'Enter your current App Lock Password / PIN to update it.';
        return;
      }

      const salt = crypto.getRandomValues(new Uint8Array(16));
      const iterations = 600000;
      const key = await deriveKey(pass, salt, iterations);
      const verify = await encryptData(key, new TextEncoder().encode('APP_LOCK_OK'));
      currentAccount.lockSalt = bufToB64(salt);
      currentAccount.lockVerify = bufToB64(verify);
      currentAccount.lockIterations = iterations;
      currentAccount.lockType = 'pin';
      currentAccount.lockLength = pinLength;
      await saveAccount(currentAccount);
      updateLockButton();
      updateSettingsOverview();
      document.getElementById('appLockCurrentPassword').value = '';
      document.getElementById('appLockPassword').value = '';
      document.getElementById('appLockPassword2').value = '';
      error.style.color = 'var(--success)';
      error.textContent = pinLength + '-digit App Lock PIN enabled. Keep it private; it cannot be recovered if forgotten.';
      toast(pinLength + '-digit App Lock PIN enabled');
    }

    async function disableAppLock() {
      const error = document.getElementById('appLockSettingsError');
      const currentPass = document.getElementById('appLockCurrentPassword').value;
      error.textContent = '';
      if (!currentAccount || !currentAccount.lockVerify) {
        error.textContent = 'App Lock is not enabled.';
        return;
      }
      if (!(await verifyAppLockPassword(currentPass, currentAccount))) {
        error.textContent = 'Enter the correct current App Lock Password to disable it.';
        return;
      }
      delete currentAccount.lockSalt;
      delete currentAccount.lockVerify;
      delete currentAccount.lockIterations;
      delete currentAccount.lockType;
      delete currentAccount.lockLength;
      await saveAccount(currentAccount);
      updateSettingsOverview();
      document.getElementById('appLockCurrentPassword').value = '';
      updateLockButton();
      error.style.color = 'var(--success)';
      error.textContent = 'App Lock disabled.';
      toast('App Lock disabled');
    }

    async function restorePersistentSession() {
      let session = null;
      try {
        session = await getPersistentSession();
      } catch (e) {
        console.warn('Persistent session could not be read:', e);
        showScreen('loginScreen');
        return false;
      }
      if (!session || !session.email || !session.key) {
        showScreen('loginScreen');
        return false;
      }

      const account = await getAccount(session.email);
      if (!account) {
        await clearPersistentSession().catch(() => {});
        showScreen('loginScreen');
        return false;
      }

      try {
        const check = await decryptData(session.key, new Uint8Array(b64ToBuf(account.verify)));
        if (new TextDecoder().decode(check) !== 'VAULT_OK') throw new Error('Stored session key is invalid');

        currentEmail = session.email;
        currentAccount = account;
        currentKey = session.key;
        accountPasswordNeedsUpgrade = false;
        document.getElementById('currentUserEmail').textContent = currentEmail;
        await updateProfilePhotoUI();
        showScreen('mainScreen');
        updateLockButton();

        if (account.lockVerify) {
          appLockNeedsRefresh = true;
          lockApp();
          toast('Welcome back. Enter your App Lock Password.');
        } else {
          await refreshFiles();
          toast('Welcome back. You are still signed in.');
        }
        return true;
      } catch (e) {
        console.warn('Stored session validation failed:', e);
        await clearPersistentSession().catch(() => {});
        showScreen('loginScreen');
        return false;
      }
    }

    async function register() {
      const email = document.getElementById('regEmail').value.trim().toLowerCase();
      const pass = document.getElementById('regPassword').value;
      const pass2 = document.getElementById('regPassword2').value;
      const err = document.getElementById('regError');
      err.textContent = '';

      if (!email || !email.includes('@')) {
        err.textContent = 'Please enter a valid email address';
        return;
      }
      const passwordError = validateStrongPassword(pass, email);
      if (passwordError) {
        err.textContent = passwordError;
        return;
      }
      if (pass !== pass2) {
        err.textContent = 'Passwords do not match';
        return;
      }

      const existing = await getAccount(email);
      if (existing) {
        err.textContent = 'An account with this email already exists. Please sign in.';
        return;
      }

      const salt = crypto.getRandomValues(new Uint8Array(16));
      const key = await deriveKey(pass, salt);
      const verify = await encryptData(key, new TextEncoder().encode('VAULT_OK'));

      const newAccount = {
        email,
        salt: bufToB64(salt),
        verify: bufToB64(verify),
        created: Date.now()
      };
      await saveAccount(newAccount);
      try {
        await savePersistentSession(email, key);
      } catch (sessionError) {
        console.warn('Could not remember this session:', sessionError);
      }

      accountPasswordNeedsUpgrade = false;
      currentEmail = email;
      currentAccount = newAccount;
      currentKey = key;
      updateLockButton();
      document.getElementById('currentUserEmail').textContent = email;
      await updateProfilePhotoUI();
      toast('Account created successfully');
      showScreen('mainScreen');
      await refreshFiles();
    }

    async function login() {
      const email = document.getElementById('loginEmail').value.trim().toLowerCase();
      const pass = document.getElementById('loginPassword').value;
      const err = document.getElementById('loginError');
      err.textContent = '';

      if (!email || !pass) {
        err.textContent = 'Please enter email and password';
        return;
      }
      if (Date.now() < loginBlockedUntil) {
        const seconds = Math.ceil((loginBlockedUntil - Date.now()) / 1000);
        err.textContent = 'Too many attempts. Try again in ' + seconds + ' seconds.';
        return;
      }

      const account = await getAccount(email);
      if (!account) {
        err.textContent = 'No account found with this email. Please create one.';
        return;
      }

      try {
        const salt = new Uint8Array(b64ToBuf(account.salt));
        const key = await deriveKey(pass, salt);
        const decrypted = await decryptData(key, new Uint8Array(b64ToBuf(account.verify)));
        const text = new TextDecoder().decode(decrypted);
        if (text !== 'VAULT_OK') throw new Error('bad password');

        loginFailedAttempts = 0;
        loginBlockedUntil = 0;
        accountPasswordNeedsUpgrade = !!validateStrongPassword(pass, email);
        currentEmail = email;
        currentAccount = account;
        currentKey = key;
        try {
          await savePersistentSession(email, key);
        } catch (sessionError) {
          console.warn('Could not remember this session:', sessionError);
          toast('Signed in, but this browser could not save the session.');
        }
        document.getElementById('currentUserEmail').textContent = email;
        await updateProfilePhotoUI();
        document.getElementById('loginPassword').value = '';
        showScreen('mainScreen');
        updateLockButton();
        if (account.lockVerify) {
          appLockNeedsRefresh = true;
          lockApp();
          toast('Enter your App Lock Password');
        } else {
          await refreshFiles();
          toast(accountPasswordNeedsUpgrade ? 'Please update your old password in Settings' : 'Signed in successfully');
          accountPasswordNeedsUpgrade = false;
        }
      } catch (e) {
        loginFailedAttempts++;
        if (loginFailedAttempts >= 5) {
          loginFailedAttempts = 0;
          loginBlockedUntil = Date.now() + 30000;
          err.textContent = 'Too many incorrect attempts. Sign-in is paused for 30 seconds.';
        } else {
          err.textContent = 'Incorrect password. Attempts left before a short pause: ' + (5 - loginFailedAttempts) + '.';
        }
        document.getElementById('loginPassword').value = '';
      }
    }

    async function logout() {
      // Explicit Logout clears the remembered sign-in; encrypted files and account remain.
      try { await clearPersistentSession(); } catch (e) { console.warn('Could not clear remembered session:', e); }
      currentEmail = null;
      currentKey = null;
      currentAccount = null;
      clearGridThumbnailUrls();
      releaseViewerObjectUrl();
      const viewerContent = document.getElementById('viewerContent');
      if (viewerContent) viewerContent.innerHTML = '';
      document.getElementById('viewerModal').classList.remove('active');
      const fileGrid = document.getElementById('fileGrid');
      if (fileGrid) fileGrid.innerHTML = '';
      const loadMore = document.getElementById('loadMoreFilesBtn');
      if (loadMore) loadMore.hidden = true;
      clearProfilePhotoObjectUrl();
      const profileImage = document.getElementById('settingsProfilePhoto');
      const profileFallback = document.getElementById('settingsProfileFallback');
      if (profileImage) { profileImage.removeAttribute('src'); profileImage.hidden = true; }
      if (profileFallback) profileFallback.hidden = false;
      appLockNeedsRefresh = false;
      accountPasswordNeedsUpgrade = false;
      lockOnReturn = false;
      files = [];
      document.getElementById('appLockModal').classList.remove('active');
      updateLockButton();
      document.getElementById('loginEmail').value = '';
      document.getElementById('loginPassword').value = '';
      document.getElementById('loginError').textContent = '';
      showScreen('loginScreen');
      toast('Logged out. Your files are safe.');
    }

    async function refreshFiles() {
      if (!currentEmail || !currentKey) return;
      const email = currentEmail;
      const key = currentKey;
      const records = await loadFileMetadataForEmail(email);
      const loadedFiles = [];
      for (const rec of records) {
        if (currentEmail !== email || currentKey !== key) return;
        try {
          let metadata;
          if (rec.meta) {
            const metadataBytes = await decryptData(key, new Uint8Array(b64ToBuf(rec.meta)));
            metadata = JSON.parse(new TextDecoder().decode(metadataBytes));
          } else {
            // Backward-compatible migration for older records with plaintext metadata.
            metadata = {
              name: rec.name || 'Untitled file',
              mime: rec.mime || 'application/octet-stream',
              size: Number(rec.size) || 0,
              type: rec.type || getFileType(rec.mime || '', rec.name || ''),
              added: Number(rec.added) || Date.now()
            };
            const encryptedMetadata = await encryptData(
              key,
              new TextEncoder().encode(JSON.stringify(metadata))
            );
            try {
              await updateEncryptedFileMetadata(rec.id, encryptedMetadata);
            } catch (migrationError) {
              console.warn('Could not migrate old file metadata:', migrationError);
            }
          }
          const mime = metadata.mime || 'application/octet-stream';
          loadedFiles.push({
            id: rec.id,
            name: metadata.name || 'Untitled file',
            mime,
            size: Number(metadata.size) || 0,
            type: metadata.type || 'file',
            added: Number(metadata.added) || Date.now(),
            hasThumb: Boolean(rec.hasThumb)
          });
        } catch (e) {
          console.warn('Could not read encrypted file metadata:', rec.id);
        }
      }
      if (currentEmail !== email || currentKey !== key) return;
      files = loadedFiles;
      files.sort((a, b) => b.added - a.added);
      renderGrid();
    }

    function formatStorage(bytes) {
      if (bytes < 1024) return bytes + ' B';
      if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
      if (bytes < 1073741824) return (bytes / 1048576).toFixed(1) + ' MB';
      if (bytes < 1099511627776) return (bytes / 1073741824).toFixed(2) + ' GB';
      return (bytes / 1099511627776).toFixed(2) + ' TB';
    }


    function clearProfilePhotoObjectUrl() {
      if (profilePhotoObjectUrl) {
        URL.revokeObjectURL(profilePhotoObjectUrl);
        profilePhotoObjectUrl = null;
      }
    }

    async function updateProfilePhotoUI() {
      const image = document.getElementById('settingsProfilePhoto');
      const fallback = document.getElementById('settingsProfileFallback');
      const status = document.getElementById('profilePhotoStatus');
      const removeButton = document.getElementById('removeProfilePhotoBtn');
      if (!image || !fallback) return;

      clearProfilePhotoObjectUrl();
      image.removeAttribute('src');
      image.hidden = true;
      fallback.hidden = false;

      if (!currentAccount || !currentKey || !currentAccount.profilePhotoEncrypted) {
        if (status) status.textContent = 'No profile photo selected. Choose a photo to save it to this email account on this device.';
        if (removeButton) removeButton.disabled = true;
        return;
      }

      try {
        const plain = await decryptData(
          currentKey,
          new Uint8Array(b64ToBuf(currentAccount.profilePhotoEncrypted))
        );
        const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        const mime = allowedTypes.includes(currentAccount.profilePhotoMime)
          ? currentAccount.profilePhotoMime
          : 'image/jpeg';
        const blob = new Blob([plain], { type: mime });
        profilePhotoObjectUrl = URL.createObjectURL(blob);
        image.src = profilePhotoObjectUrl;
        image.hidden = false;
        fallback.hidden = true;
        if (status) status.textContent = 'Profile photo saved for ' + currentEmail + ' on this device.';
        if (removeButton) removeButton.disabled = false;
      } catch (error) {
        console.warn('Profile photo could not be decrypted:', error);
        if (status) status.textContent = 'The saved profile photo could not be opened. You can choose a new photo.';
        if (removeButton) removeButton.disabled = false;
      }
    }

    async function saveProfilePhoto(file) {
      const status = document.getElementById('profilePhotoStatus');
      if (!currentEmail || !currentAccount || !currentKey) {
        if (status) status.textContent = 'Please sign in before choosing a profile photo.';
        return;
      }
      if (!file) return;
      const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
      if (!allowedTypes.includes((file.type || '').toLowerCase())) {
        if (status) status.textContent = 'Choose a JPG, PNG, WEBP, or GIF image.';
        toast('Unsupported profile photo format');
        return;
      }
      const maxBytes = 5 * 1024 * 1024;
      if (file.size <= 0 || file.size > maxBytes) {
        if (status) status.textContent = 'Profile photo must be smaller than 5 MB.';
        toast('Profile photo must be smaller than 5 MB');
        return;
      }

      try {
        const encrypted = await encryptData(currentKey, await file.arrayBuffer());
        currentAccount.profilePhotoEncrypted = bufToB64(encrypted);
        currentAccount.profilePhotoMime = file.type.toLowerCase();
        currentAccount.profilePhotoUpdatedAt = Date.now();
        await saveAccount(currentAccount);
        await updateProfilePhotoUI();
        toast('Profile photo saved to your account');
      } catch (error) {
        console.error('Could not save profile photo:', error);
        if (status) status.textContent = 'Could not save this photo. Please try another image.';
        toast('Profile photo could not be saved');
      }
    }

    async function removeProfilePhoto() {
      if (!currentAccount || !currentEmail) return;
      if (!currentAccount.profilePhotoEncrypted) {
        await updateProfilePhotoUI();
        return;
      }
      if (!confirm('Remove your profile photo from this local account?')) return;
      if (!(await verifyRealPasswordForDestructiveAction('remove your profile photo'))) return;
      delete currentAccount.profilePhotoEncrypted;
      delete currentAccount.profilePhotoMime;
      delete currentAccount.profilePhotoUpdatedAt;
      try {
        await saveAccount(currentAccount);
        await updateProfilePhotoUI();
        toast('Profile photo removed');
      } catch (error) {
        console.error('Could not remove profile photo:', error);
        toast('Could not remove profile photo');
      }
    }

    function updateSettingsOverview() {
      const emailEl = document.getElementById('settingsAccountEmail');
      const countEl = document.getElementById('settingsFileCount');
      const usedEl = document.getElementById('settingsStorageUsed');
      const fillEl = document.getElementById('settingsStorageFill');
      const progressEl = fillEl ? fillEl.parentElement : null;
      const lockEl = document.getElementById('settingsLockStatus');

      if (emailEl) emailEl.textContent = currentEmail || 'No signed-in account';
      const totalBytes = files.reduce((sum, file) => sum + (Number(file.size) || 0), 0);
      if (countEl) countEl.textContent = String(files.length);
      if (usedEl) usedEl.textContent = formatStorage(totalBytes);

      const percent = Math.min(100, Math.max(0, (totalBytes / MAX_STORAGE) * 100));
      if (fillEl) fillEl.style.width = percent.toFixed(4) + '%';
      if (progressEl) progressEl.setAttribute('aria-valuenow', String(Math.round(percent)));

      if (lockEl) {
        const enabled = !!(currentAccount && currentAccount.lockVerify);
        lockEl.textContent = enabled
          ? 'Enabled · ' + (currentAccount.lockLength || 0) + '-digit PIN'
          : 'Not enabled';
        lockEl.classList.toggle('is-enabled', enabled);
      }
    }

    function renderGrid() {
      const grid = document.getElementById('fileGrid');
      const empty = document.getElementById('emptyState');
      const countEl = document.getElementById('fileCount');
      clearGridThumbnailUrls();
      if (countEl) {
        const totalBytes = files.reduce((sum, f) => sum + (f.size || 0), 0);
        countEl.textContent = files.length + ' files · ' + formatStorage(totalBytes) + ' / 5 TB';
        countEl.style.color = totalBytes >= MAX_STORAGE * 0.95 ? 'var(--danger)' : 'var(--muted)';
      }
      updateSettingsOverview();
      const filtered = currentFilter === 'all'
        ? files
        : currentFilter === 'file'
          ? files.filter(f => f.type !== 'image' && f.type !== 'video')
          : files.filter(f => f.type === currentFilter);

      const loadMoreButton = document.getElementById('loadMoreFilesBtn');
      if (filtered.length === 0) {
        grid.innerHTML = '';
        empty.hidden = false;
        if (loadMoreButton) loadMoreButton.hidden = true;
        return;
      }
      empty.hidden = true;
      const visibleFiles = filtered.slice(0, gridDisplayLimit);

      grid.innerHTML = visibleFiles.map(f => {
        const safeId = escapeHTML(f.id);
        let thumb = '';
        const isVisualMedia = f.type === 'image' || f.type === 'video';
        const canPreviewInGrid = f.size > 0 && (f.hasThumb || f.size <= MAX_LEGACY_GRID_PREVIEW_BYTES);
        if (isVisualMedia && canPreviewInGrid) {
          const fallbackIcon = f.type === 'image' ? '🖼️' : '🎬';
          thumb = `<div class="thumb-placeholder" aria-hidden="true">${fallbackIcon}</div><img data-lazy-thumb="${safeId}" alt="${f.type === 'video' ? 'Video preview' : 'Photo preview'}" loading="lazy" decoding="async" />${f.type === 'video' ? '<span class="video-play-mark" aria-hidden="true">▶</span>' : ''}`;
        } else {
          const icons = { image: '🖼️', video: '🎬', audio: '🎵', apk: '📦', file: '📄' };
          thumb = `<div class="thumb-placeholder" aria-hidden="true" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:2.5rem;">${icons[f.type] || '📄'}</div>`;
        }
        return `
          <div class="card" data-id="${safeId}">
            ${thumb}
            <div class="type-badge">${escapeHTML(f.type)}</div>
            <div class="overlay">${escapeHTML(f.name)}</div>
          </div>`;
      }).join('');

      grid.querySelectorAll('.card').forEach(card => {
        card.addEventListener('click', () => openViewer(card.dataset.id));
      });
      grid.querySelectorAll('img[data-lazy-thumb]').forEach(image => {
        image.addEventListener('error', () => {
          const url = gridThumbUrls.get(image);
          if (url) URL.revokeObjectURL(url);
          gridThumbUrls.delete(image);
          image.removeAttribute('src');
        }, { once: true });
      });
      if (loadMoreButton) {
        const remaining = filtered.length - visibleFiles.length;
        loadMoreButton.hidden = remaining <= 0;
        loadMoreButton.textContent = remaining > 0 ? 'Load more files · ' + remaining + ' remaining' : 'Load more files';
      }
      observeGridThumbnails(grid);
    }

    async function addFiles(fileList) {
      if (!fileList || !fileList.length || !currentEmail || !currentKey) return;

      // Accept any file type (PDF, ZIP, images, videos, audio, and other files).
      const selectedFiles = Array.from(fileList);

      // Process up to 200 files in each upload batch.
      const batch = selectedFiles.slice(0, MAX_BATCH);
      if (selectedFiles.length > MAX_BATCH) {
        toast('You selected ' + selectedFiles.length + ' files. Uploading the first ' + MAX_BATCH + ' only. Select the next batch after this finishes.');
      } else {
        toast('Adding ' + batch.length + ' file(s)...');
      }

      // Check 5 TB total storage limit
      const currentBytes = files.reduce((sum, f) => sum + (f.size || 0), 0);
      let usedInBatch = 0;
      const toUpload = [];
      for (const file of batch) {
        if (currentBytes + usedInBatch + file.size > MAX_STORAGE) {
          toast('5 TB storage limit reached. Cannot add more.');
          break;
        }
        toUpload.push(file);
        usedInBatch += file.size;
      }

      if (toUpload.length === 0) {
        toast('Storage full or no valid files');
        return;
      }

      let added = 0;
      for (const file of toUpload) {
        try {
          const buffer = await file.arrayBuffer();
          const encrypted = await encryptData(currentKey, buffer);
          const id = crypto.randomUUID();
          const type = getFileType(file.type || '', file.name);
          let encryptedThumbnail = null;
          let thumbnailMime = 'image/webp';
          if (type === 'image' || type === 'video') {
            try {
              const thumbnailBlob = await createMediaThumbnail(file, type);
              if (thumbnailBlob) {
                encryptedThumbnail = bufToB64(await encryptData(currentKey, await thumbnailBlob.arrayBuffer()));
                thumbnailMime = thumbnailBlob.type || 'image/webp';
              }
            } catch (thumbnailError) {
              console.warn('Thumbnail creation skipped for:', file.name, thumbnailError);
            }
          }
          const metadata = {
            name: file.name,
            mime: file.type || 'application/octet-stream',
            size: file.size,
            type,
            added: Date.now()
          };
          const encryptedMetadata = await encryptData(
            currentKey,
            new TextEncoder().encode(JSON.stringify(metadata))
          );
          const fileRecord = {
            id,
            email: currentEmail.toLowerCase(),
            data: bufToB64(encrypted),
            meta: bufToB64(encryptedMetadata)
          };
          if (encryptedThumbnail) {
            fileRecord.thumb = encryptedThumbnail;
            fileRecord.thumbMime = thumbnailMime;
          }
          await saveFileRecord(fileRecord);
          added++;
        } catch (e) {
          console.error(e);
          toast('Error adding some files');
        }
      }
      await refreshFiles();
      if (added > 0) {
        toast(added + ' file(s) added successfully');
      }
    }

    async function openViewer(id) {
      const f = files.find(x => x.id === id);
      if (!f) return;
      selectedId = id;
      releaseViewerObjectUrl();
      document.getElementById('viewerTitle').textContent = f.name;
      const content = document.getElementById('viewerContent');
      content.innerHTML = '';
      const modal = document.getElementById('viewerModal');
      modal.classList.add('active');

      if (f.type === 'image' || f.type === 'video' || f.type === 'audio') {
        const loading = document.createElement('p');
        loading.className = 'muted';
        loading.textContent = 'Opening securely…';
        content.appendChild(loading);
        try {
          const blob = await getDecryptedFileBlob(f);
          if (selectedId !== id || !modal.classList.contains('active')) return;
          releaseViewerObjectUrl();
          viewerObjectUrl = URL.createObjectURL(blob);
          content.innerHTML = '';
          if (f.type === 'image') {
            const image = document.createElement('img');
            image.className = 'preview';
            image.alt = f.name;
            image.decoding = 'async';
            image.src = viewerObjectUrl;
            content.appendChild(image);
          } else if (f.type === 'video') {
            const video = document.createElement('video');
            video.className = 'preview';
            video.controls = true;
            video.autoplay = true;
            video.playsInline = true;
            video.src = viewerObjectUrl;
            content.appendChild(video);
          } else {
            const audio = document.createElement('audio');
            audio.controls = true;
            audio.autoplay = true;
            audio.style.width = '100%';
            audio.src = viewerObjectUrl;
            const label = document.createElement('p');
            label.style.textAlign = 'center';
            label.style.marginTop = '12px';
            label.textContent = f.name + ' · ' + formatSize(f.size);
            content.append(audio, label);
          }
        } catch (error) {
          console.error('Could not open file preview:', error);
          if (selectedId === id && modal.classList.contains('active')) {
            content.textContent = 'This file could not be opened. Try downloading it instead.';
          }
        }
      } else {
        const details = document.createElement('div');
        details.style.textAlign = 'center';
        details.style.padding = '30px';
        const icon = document.createElement('div');
        icon.style.fontSize = '3rem';
        icon.textContent = f.type === 'apk' ? '📦' : '📄';
        const name = document.createElement('p');
        name.style.marginTop = '12px';
        name.textContent = f.name;
        const size = document.createElement('p');
        size.className = 'muted';
        size.textContent = formatSize(f.size);
        details.append(icon, name, size);
        content.appendChild(details);
      }
    }

    async function downloadSelected() {
      const f = files.find(x => x.id === selectedId);
      if (!f) return;
      try {
        const blob = await getDecryptedFileBlob(f);
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = f.name;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 60000);
        toast('Download started');
      } catch (error) {
        console.error('File download failed:', error);
        toast('Could not download this file. Please unlock the vault and try again.');
      }
    }

    async function deleteSelected() {
      if (!selectedId) return;
      if (!confirm('Delete this file permanently?')) return;
      if (!(await verifyRealPasswordForDestructiveAction('delete this file'))) return;
      await deleteFileRecord(selectedId);
      document.getElementById('viewerModal').classList.remove('active');
      releaseViewerObjectUrl();
      document.getElementById('viewerContent').innerHTML = '';
      selectedId = null;
      await refreshFiles();
      toast('File deleted');
    }

    async function changePassword() {
      const p1 = document.getElementById('newPassword').value;
      const p2 = document.getElementById('newPassword2').value;
      const err = document.getElementById('settingsError');
      err.style.color = 'var(--danger)';
      err.textContent = '';

      const passwordError = validateStrongPassword(p1, currentEmail);
      if (passwordError) {
        err.textContent = passwordError;
        return;
      }
      if (p1 !== p2) {
        err.textContent = 'Passwords do not match';
        return;
      }

      const account = await getAccount(currentEmail);
      if (!account) {
        err.textContent = 'Account not found.';
        return;
      }
      if (await passwordMatchesAccount(p1, account)) {
        err.textContent = 'Choose a new password different from your current password.';
        return;
      }
      if (account.lockVerify && await verifyAppLockPassword(p1, account)) {
        err.textContent = 'Account Password must be different from your App Lock Password.';
        return;
      }

      try {
        const newSalt = crypto.getRandomValues(new Uint8Array(16));
        const newKey = await deriveKey(p1, newSalt);
        const storedRecords = await loadFilesForEmail(currentEmail);
        const updatedRecords = [];

        // Re-encrypt every stored file before committing the new password.
        // The account and file updates are then written in one IndexedDB transaction.
        for (const record of storedRecords) {
          const plain = await decryptData(currentKey, new Uint8Array(b64ToBuf(record.data)));
          const encrypted = await encryptData(newKey, plain);
          let metadata;
          if (record.meta) {
            const metadataBytes = await decryptData(currentKey, new Uint8Array(b64ToBuf(record.meta)));
            metadata = JSON.parse(new TextDecoder().decode(metadataBytes));
          } else {
            metadata = {
              name: record.name || 'Untitled file',
              mime: record.mime || 'application/octet-stream',
              size: Number(record.size) || plain.byteLength,
              type: record.type || 'file',
              added: Number(record.added) || Date.now()
            };
          }
          const encryptedMetadata = await encryptData(
            newKey,
            new TextEncoder().encode(JSON.stringify(metadata))
          );
          const { name, mime, size, type, added, ...privateRecord } = record;
          const updatedRecord = {
            ...privateRecord,
            data: bufToB64(encrypted),
            meta: bufToB64(encryptedMetadata)
          };
          if (record.thumb) {
            const thumbnailPlain = await decryptData(currentKey, new Uint8Array(b64ToBuf(record.thumb)));
            updatedRecord.thumb = bufToB64(await encryptData(newKey, thumbnailPlain));
          }
          updatedRecords.push(updatedRecord);
        }

        if (account.profilePhotoEncrypted) {
          const photoPlain = await decryptData(
            currentKey,
            new Uint8Array(b64ToBuf(account.profilePhotoEncrypted))
          );
          account.profilePhotoEncrypted = bufToB64(await encryptData(newKey, photoPlain));
        }

        const verify = await encryptData(newKey, new TextEncoder().encode('VAULT_OK'));
        account.salt = bufToB64(newSalt);
        account.verify = bufToB64(verify);
        await savePasswordMigration(updatedRecords, account);

        currentKey = newKey;
        currentAccount = account;
        await updateProfilePhotoUI();
        accountPasswordNeedsUpgrade = false;
        try {
          await savePersistentSession(currentEmail, newKey);
        } catch (sessionError) {
          console.warn('Could not refresh remembered session after password change:', sessionError);
          await clearPersistentSession().catch(() => {});
        }
        document.getElementById('newPassword').value = '';
        document.getElementById('newPassword2').value = '';
        err.style.color = 'var(--success)';
        err.textContent = 'Password updated. Your saved files were re-encrypted successfully.';
        toast('Password updated successfully');
      } catch (e) {
        console.error('Password update failed:', e);
        err.style.color = 'var(--danger)';
        err.textContent = 'Password update failed. Your old password and files have been kept unchanged.';
      }
    }

    async function wipeAllFiles() {
      if (!confirm('Delete ALL your files permanently? This cannot be undone.')) return;
      if (!confirm('Are you really sure? All photos, videos and files will be gone forever.')) return;
      if (!(await verifyRealPasswordForDestructiveAction('delete ALL your files'))) return;
      await deleteAllFilesForEmail(currentEmail);
      files = [];
      renderGrid();
      document.getElementById('settingsModal').classList.remove('active');
      toast('All files deleted');
    }

    async function deleteCurrentAccount() {
      const passwordInput = document.getElementById('deleteAccountPassword');
      const confirmInput = document.getElementById('deleteAccountConfirm');
      const error = document.getElementById('deleteAccountError');
      error.textContent = '';
      error.style.color = 'var(--danger)';

      if (!currentEmail || !currentAccount) {
        error.textContent = 'No signed-in local account was found.';
        return;
      }
      if (confirmInput.value.trim() !== 'DELETE') {
        error.textContent = 'Type DELETE exactly to confirm.';
        return;
      }
      const accountPassword = passwordInput.value;
      if (!accountPassword || !(await passwordMatchesAccount(accountPassword, currentAccount))) {
        error.textContent = 'Enter the correct current account password.';
        passwordInput.value = '';
        return;
      }
      if (!confirm('Permanently delete this local account and all its encrypted files from this device? This cannot be undone.')) return;

      const emailToDelete = currentEmail;
      try {
        await deleteLocalAccountAndData(emailToDelete);
        currentEmail = null;
        currentKey = null;
        currentAccount = null;
        clearGridThumbnailUrls();
        releaseViewerObjectUrl();
        const viewerContent = document.getElementById('viewerContent');
        if (viewerContent) viewerContent.innerHTML = '';
        clearProfilePhotoObjectUrl();
        const profileImage = document.getElementById('settingsProfilePhoto');
        const profileFallback = document.getElementById('settingsProfileFallback');
        if (profileImage) { profileImage.removeAttribute('src'); profileImage.hidden = true; }
        if (profileFallback) profileFallback.hidden = false;
        appLockNeedsRefresh = false;
        accountPasswordNeedsUpgrade = false;
        lockOnReturn = false;
        files = [];
        const fileGrid = document.getElementById('fileGrid');
        if (fileGrid) fileGrid.innerHTML = '';
        const loadMore = document.getElementById('loadMoreFilesBtn');
        if (loadMore) loadMore.hidden = true;
        document.getElementById('viewerModal').classList.remove('active');
        selectedId = null;
        passwordInput.value = '';
        confirmInput.value = '';
        document.getElementById('settingsModal').classList.remove('active');
        document.getElementById('appLockModal').classList.remove('active');
        document.getElementById('loginEmail').value = '';
        document.getElementById('loginPassword').value = '';
        document.getElementById('currentUserEmail').textContent = '';
        updateLockButton();
        showScreen('loginScreen');
        toast('Local account and its vault data deleted from this device.');
      } catch (e) {
        console.error('Local account deletion failed:', e);
        error.textContent = 'Could not delete local account data. Please try again.';
      }
    }

    document.getElementById('loginBtn').addEventListener('click', login);
    document.getElementById('registerBtn').addEventListener('click', register);
    document.getElementById('showRegisterBtn').addEventListener('click', () => showScreen('registerScreen'));
    document.getElementById('showLoginBtn').addEventListener('click', () => showScreen('loginScreen'));

    document.getElementById('loginPassword').addEventListener('keydown', e => { if (e.key === 'Enter') login(); });
    document.getElementById('regPassword2').addEventListener('keydown', e => { if (e.key === 'Enter') register(); });

    document.getElementById('logoutBtn').addEventListener('click', logout);
    document.getElementById('lockBtn').addEventListener('click', lockApp);
    document.getElementById('unlockAppBtn').addEventListener('click', unlockApp);
    document.getElementById('appUnlockPassword').addEventListener('input', () => {
      const input = document.getElementById('appUnlockPassword');
      const requiredLength = Number(currentAccount?.lockLength || 0);
      if ((requiredLength === 4 || requiredLength === 6) && input.value.length === requiredLength && /^\d+$/.test(input.value)) {
        unlockApp();
      }
    });
    document.getElementById('appUnlockPassword').addEventListener('keydown', e => { if (e.key === 'Enter') unlockApp(); });
    document.getElementById('setAppLockBtn').addEventListener('click', setAppLockPassword);
    document.getElementById('disableAppLockBtn').addEventListener('click', disableAppLock);
    document.getElementById('appLockPinLength').addEventListener('change', syncAppLockPinLength);
    syncAppLockPinLength();

    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') {
        if (currentEmail && currentKey && currentAccount && currentAccount.lockVerify) lockOnReturn = true;
      } else if (lockOnReturn) {
        lockOnReturn = false;
        lockApp();
      }
    });

    document.getElementById('addBtn').addEventListener('click', () => {
      document.getElementById('fileInput').click();
    });
    document.getElementById('fileInput').addEventListener('change', e => {
      addFiles(e.target.files);
      e.target.value = '';
    });

    document.getElementById('loadMoreFilesBtn').addEventListener('click', () => {
      gridDisplayLimit += GRID_PAGE_SIZE;
      renderGrid();
    });

    document.getElementById('tabs').addEventListener('click', e => {
      if (e.target.classList.contains('tab')) {
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        e.target.classList.add('active');
        currentFilter = e.target.dataset.type;
        gridDisplayLimit = GRID_PAGE_SIZE;
        renderGrid();
      }
    });

    document.getElementById('settingsBtn').addEventListener('click', () => {
      document.getElementById('settingsModal').classList.add('active');
      document.getElementById('settingsError').textContent = '';
      document.getElementById('deleteAccountError').textContent = '';
      document.getElementById('deleteAccountPassword').value = '';
      document.getElementById('deleteAccountConfirm').value = '';
      const lockError = document.getElementById('appLockSettingsError');
      lockError.textContent = '';
      lockError.style.color = 'var(--danger)';
      const pinLength = document.getElementById('appLockPinLength');
      pinLength.value = String(currentAccount?.lockLength || 6);
      syncAppLockPinLength();
      updateSettingsOverview();
      updateProfilePhotoUI();
    });
    document.getElementById('closeSettingsTop').addEventListener('click', () => {
      document.getElementById('settingsModal').classList.remove('active');
    });
    document.getElementById('closeSettings').addEventListener('click', () => {
      document.getElementById('settingsModal').classList.remove('active');
    });

    // Settings-only search: filters existing sections without changing their controls or behavior.
    const settingsSearch = document.getElementById('settingsSearch');
    if (settingsSearch) {
      settingsSearch.addEventListener('input', () => {
        const query = settingsSearch.value.trim().toLowerCase();
        const sections = Array.from(document.querySelectorAll('#settingsModal .settings-scroll .settings-section'));
        let shown = 0;
        sections.forEach(section => {
          const match = !query || section.textContent.toLowerCase().includes(query);
          section.hidden = !match;
          if (match) shown += 1;
        });
        const status = document.getElementById('settingsSearchStatus');
        if (status) status.textContent = query
          ? (shown ? `${shown} settings section(s) found.` : 'No matching settings. Try another word.')
          : 'All settings are shown.';
      });
    }
    document.getElementById('changePasswordBtn').addEventListener('click', changePassword);
    document.getElementById('chooseProfilePhotoBtn').addEventListener('click', () => {
      document.getElementById('profilePhotoInput').click();
    });
    document.getElementById('profilePhotoInput').addEventListener('change', async (event) => {
      const file = event.target.files && event.target.files[0];
      await saveProfilePhoto(file);
      event.target.value = '';
    });
    document.getElementById('removeProfilePhotoBtn').addEventListener('click', removeProfilePhoto);
    document.getElementById('wipeBtn').addEventListener('click', wipeAllFiles);
    document.getElementById('deleteAccountBtn').addEventListener('click', deleteCurrentAccount);
    document.getElementById('installAppBtn').addEventListener('click', installApp);

    document.getElementById('aboutBtn').addEventListener('click', () => {
      document.getElementById('settingsModal').classList.remove('active');
      document.getElementById('aboutModal').classList.add('active');
    });
    document.getElementById('closeAbout').addEventListener('click', () => {
      document.getElementById('aboutModal').classList.remove('active');
    });
    document.getElementById('privacyBtn').addEventListener('click', () => {
      document.getElementById('settingsModal').classList.remove('active');
      document.getElementById('privacyModal').classList.add('active');
    });
    document.getElementById('closePrivacy').addEventListener('click', () => {
      document.getElementById('privacyModal').classList.remove('active');
    });

    document.getElementById('closeViewer').addEventListener('click', () => {
      document.getElementById('viewerModal').classList.remove('active');
      releaseViewerObjectUrl();
      document.getElementById('viewerContent').innerHTML = '';
      selectedId = null;
    });
    document.getElementById('downloadBtn').addEventListener('click', downloadSelected);
    document.getElementById('deleteBtn').addEventListener('click', deleteSelected);

    // ========== PWA Support (static manifest + service worker) ==========
    let deferredInstallPrompt = null;

    function setupPWA() {
      // Service workers require HTTPS (or localhost). The app still works in a normal browser.
      if ('serviceWorker' in navigator && window.isSecureContext) {
        navigator.serviceWorker.register('./sw.js', { scope: './' })
          .then(() => console.log('Service Worker registered'))
          .catch((err) => console.warn('Service Worker registration failed:', err.message));
      }

      // Capture the browser's native install prompt without changing the existing UI.
      window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredInstallPrompt = e;
        const btn = document.getElementById('installAppBtn');
        if (btn) btn.style.display = 'block';
      });

      window.addEventListener('appinstalled', () => {
        deferredInstallPrompt = null;
        const btn = document.getElementById('installAppBtn');
        if (btn) btn.style.display = 'none';
        toast('App installed successfully!');
      });
    }

    async function installApp() {
      if (!deferredInstallPrompt) {
        toast('Install not available yet. Open the site via HTTPS first.');
        return;
      }
      deferredInstallPrompt.prompt();
      const { outcome } = await deferredInstallPrompt.userChoice;
      if (outcome === 'accepted') {
        toast('Installing...');
      }
      deferredInstallPrompt = null;
    }

    (async () => {
      try {
        db = await openDB();
        setupPasswordVisibility();
        const versionLabel = document.getElementById('appVersion');
        if (versionLabel) versionLabel.textContent = APP_VERSION;
        await restorePersistentSession();
        setupPWA();
      } catch (startupError) {
        console.error('Private Vault startup failed:', startupError);
        showScreen('loginScreen');
        const error = document.getElementById('loginError');
        if (error) error.textContent = 'Could not open local vault storage. Please reload the app.';
      }
    })();
